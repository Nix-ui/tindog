function sumar(a, b) {
  return a + b;
}

export default sumar;
